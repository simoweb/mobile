$('document').ready(function(){
  $("#tab-bar li").bind("touchend", function(e){
    alert("Coming soon!");
  });
});