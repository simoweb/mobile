$('document').ready(function(){
  $("#tab-bar li").click(function(e){
    e.preventDefault();
    alert("Coming soon!");
  });
})